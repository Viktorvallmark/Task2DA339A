package org.example.partyView;

public enum ButtonType {
  Add,
  Change,
  Delete,
  Statistics,
}
